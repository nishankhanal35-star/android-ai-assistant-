package com.example.ai

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

/**
 * Data model for ElevenLabs Text-to-Speech API request payload.
 * Supports the [MODEL_MULTILINGUAL_V2] model (`eleven_multilingual_v2`) for high-quality Nepali
 * and multilingual voice synthesis.
 */
@JsonClass(generateAdapter = true)
data class ElevenLabsTtsRequest(
    @Json(name = "text")
    val text: String,

    @Json(name = "model_id")
    val modelId: String = MODEL_MULTILINGUAL_V2,

    @Json(name = "voice_settings")
    val voiceSettings: ElevenLabsVoiceSettings? = ElevenLabsVoiceSettings()
) {
    companion object {
        const val MODEL_MULTILINGUAL_V2 = "eleven_multilingual_v2"
        const val MODEL_MONOLINGUAL_V1 = "eleven_monolingual_v1"
        const val MODEL_TURBO_V2_5 = "eleven_turbo_v2_5"
        const val MODEL_MULTILINGUAL_V1 = "eleven_multilingual_v1"
    }
}

/**
 * Voice settings for ElevenLabs Text-to-Speech API request.
 */
@JsonClass(generateAdapter = true)
data class ElevenLabsVoiceSettings(
    @Json(name = "stability")
    val stability: Double = 0.45,

    @Json(name = "similarity_boost")
    val similarityBoost: Double = 0.85,

    @Json(name = "style")
    val style: Double = 0.05,

    @Json(name = "use_speaker_boost")
    val useSpeakerBoost: Boolean = true
)

/**
 * Data model representing an ElevenLabs voice definition.
 */
@JsonClass(generateAdapter = true)
data class ElevenLabsVoice(
    @Json(name = "voice_id")
    val voiceId: String,

    @Json(name = "name")
    val name: String,

    @Json(name = "category")
    val category: String? = null
)

/**
 * Response payload containing available ElevenLabs voices.
 */
@JsonClass(generateAdapter = true)
data class ElevenLabsVoicesResponse(
    @Json(name = "voices")
    val voices: List<ElevenLabsVoice>
)
