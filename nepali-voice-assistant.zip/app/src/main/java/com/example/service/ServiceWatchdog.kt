package com.example.service

import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.work.BackoffPolicy
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.example.data.Storage
import java.util.concurrent.TimeUnit

class ServiceWatchdog(appContext: Context, workerParams: WorkerParameters) :
    Worker(appContext, workerParams) {

    companion object {
        private const val WORK_NAME = "nepali_assistant_watchdog"

        fun scheduleWatchdog(context: Context) {
            val watchdogRequest = PeriodicWorkRequestBuilder<ServiceWatchdog>(15, TimeUnit.MINUTES)
                .setBackoffCriteria(BackoffPolicy.LINEAR, 1, TimeUnit.MINUTES)
                .build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                watchdogRequest
            )
        }
    }

    override fun doWork(): Result {
        val context = applicationContext
        if (Storage.isServiceActive(context) && !VoiceForegroundService.isRunning) {
            Log.w("ServiceWatchdog", "Service should be active but is not running! Reviving VoiceForegroundService...")
            try {
                val serviceIntent = Intent(context, VoiceForegroundService::class.java).apply {
                    action = VoiceForegroundService.ACTION_START
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(serviceIntent)
                } else {
                    context.startService(serviceIntent)
                }
            } catch (e: Exception) {
                Log.e("ServiceWatchdog", "Error reviving VoiceForegroundService", e)
            }
        }
        return Result.success()
    }
}
