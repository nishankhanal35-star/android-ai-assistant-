package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ai.GeminiService
import com.example.ui.viewmodel.MainViewModel
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    val currentApiKey by viewModel.apiKey.collectAsState()
    val elevenApiKey by viewModel.elevenLabsApiKey.collectAsState()
    val elevenVoiceId by viewModel.elevenLabsVoiceId.collectAsState()
    val useElevenLabs by viewModel.useElevenLabs.collectAsState()
    val speechPitch by viewModel.speechPitch.collectAsState()
    val speechRate by viewModel.speechRate.collectAsState()

    var apiKeyInput by remember(currentApiKey) { mutableStateOf(currentApiKey) }
    var elevenKeyInput by remember(elevenApiKey) { mutableStateOf(elevenApiKey) }
    var elevenVoiceInput by remember(elevenVoiceId) { mutableStateOf(elevenVoiceId) }
    var elevenEnabled by remember(useElevenLabs) { mutableStateOf(useElevenLabs) }

    var showApiKey by remember { mutableStateOf(false) }
    var showElevenKey by remember { mutableStateOf(false) }
    var isTestingKey by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "सेटिङहरू (Settings)",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )

        // Gemini API Key Config Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Key,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Gemini AI API कुञ्जी (API Key)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "उच्चस्तरीय नेपाली एआई कुराकानी र आदेश प्रशोधनका लागि Gemini API Key राख्नुहोस्।",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = apiKeyInput,
                    onValueChange = { apiKeyInput = it },
                    label = { Text("Gemini API Key") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("api_key_input"),
                    singleLine = true,
                    visualTransformation = if (showApiKey) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = {
                        IconButton(onClick = { showApiKey = !showApiKey }) {
                            Icon(
                                imageVector = if (showApiKey) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                contentDescription = "Show/Hide Key"
                            )
                        }
                    }
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Button(
                        onClick = {
                            viewModel.updateApiKey(apiKeyInput)
                            Toast.makeText(context, "API Key सुरक्षित गरियो!", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.testTag("save_api_key_btn")
                    ) {
                        Icon(imageVector = Icons.Default.Check, contentDescription = null)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("सुरक्षित गर्नुहोस्")
                    }

                    Button(
                        onClick = {
                            isTestingKey = true
                            viewModel.updateApiKey(apiKeyInput)
                            coroutineScope.launch {
                                val result = GeminiService.processCommand(context, "नमस्ते")
                                isTestingKey = false
                                if (result.reply.isNotBlank()) {
                                    Toast.makeText(context, "सफलतापूर्वक जोडियो! उत्तर: ${result.reply}", Toast.LENGTH_LONG).show()
                                } else {
                                    Toast.makeText(context, "परीक्षण असफल भयो, API key जाँच्नुहोस्।", Toast.LENGTH_SHORT).show()
                                }
                            }
                        },
                        enabled = !isTestingKey,
                        modifier = Modifier.testTag("test_api_key_btn")
                    ) {
                        Text(if (isTestingKey) "जाँच्दैछ..." else "जाँच्नुहोस् (Test)")
                    }
                }
            }
        }

        // ElevenLabs API Config Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.RecordVoiceOver,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "ElevenLabs आवाज प्रयोग (TTS)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Switch(
                        checked = elevenEnabled,
                        onCheckedChange = { elevenEnabled = it },
                        modifier = Modifier.testTag("elevenlabs_switch")
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "इलेभेनल्याब्स Multilingual V2 मोडल मार्फत अत्यन्तै प्राकृतिक र स्पष्ट नेपाली आवाजमा सुन्नुहोस्। (अन्यथा अन-डिभाइस TTS चल्नेछ)।",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = elevenKeyInput,
                    onValueChange = { elevenKeyInput = it },
                    label = { Text("ElevenLabs API Key") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("elevenlabs_key_input"),
                    singleLine = true,
                    visualTransformation = if (showElevenKey) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = {
                        IconButton(onClick = { showElevenKey = !showElevenKey }) {
                            Icon(
                                imageVector = if (showElevenKey) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                contentDescription = "Show/Hide Key"
                            )
                        }
                    }
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = elevenVoiceInput,
                    onValueChange = { elevenVoiceInput = it },
                    label = { Text("ElevenLabs Voice ID (उदा: 21m00Tcm4TlvDq8ikWAM)") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("elevenlabs_voice_input"),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "लोकप्रिय आवाज रोज्नुहोस् (Quick Preset):",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.SemiBold
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val presets = listOf(
                        "Rachel" to "21m00Tcm4TlvDq8ikWAM",
                        "Adam" to "pNInz6obpgDQGcFmaJgB",
                        "Nicole" to "piTKA4u4Ltn42oKOBSOU",
                        "Bella" to "EXAVITQu4vr4xnSDxMaL"
                    )
                    presets.forEach { (name, id) ->
                        FilterChip(
                            selected = (elevenVoiceInput == id),
                            onClick = { elevenVoiceInput = id },
                            label = { Text(name, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Button(
                        onClick = {
                            viewModel.updateElevenLabsSettings(elevenKeyInput, elevenVoiceInput, elevenEnabled)
                            Toast.makeText(context, "ElevenLabs सेटिङ सुरक्षित गरियो!", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.testTag("save_elevenlabs_btn")
                    ) {
                        Icon(imageVector = Icons.Default.Check, contentDescription = null)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("सुरक्षित गर्नुहोस्")
                    }

                    Button(
                        onClick = {
                            viewModel.updateElevenLabsSettings(elevenKeyInput, elevenVoiceInput, elevenEnabled)
                            viewModel.speak("नमस्ते, इलेभेनल्याब्स प्राकृतिक नेपाली आवाज परीक्षण सफल भयो।")
                        },
                        modifier = Modifier.testTag("test_elevenlabs_btn")
                    ) {
                        Text("परीक्षण (Test ElevenLabs)")
                    }
                }
            }
        }

        // Speech Voice Pitch & Speed Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.RecordVoiceOver,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "नेपाली आवाज र गति सेटिङ (Voice Tuning)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text("आवाजको तीक्ष्णता (Pitch): ${"%.2f".format(speechPitch)}x")
                Slider(
                    value = speechPitch,
                    onValueChange = { viewModel.setSpeechPitch(it) },
                    valueRange = 0.5f..1.8f,
                    modifier = Modifier.testTag("pitch_slider")
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text("बोल्ने गति (Speech Speed): ${"%.2f".format(speechRate)}x")
                Slider(
                    value = speechRate,
                    onValueChange = { viewModel.setSpeechRate(it) },
                    valueRange = 0.5f..1.8f,
                    modifier = Modifier.testTag("rate_slider")
                )

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = {
                        viewModel.speak("नमस्ते! यो तपाईंको नेपाली भोइस असिस्टेन्टको परीक्षण आवाज हो।")
                    },
                    modifier = Modifier.fillMaxWidth().testTag("test_voice_btn")
                ) {
                    Icon(imageVector = Icons.Default.Speed, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("आवाज परीक्षण गर्नुहोस् (Test Voice)")
                }
            }
        }

        // About & Version Info Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "नेपाली भोइस असिस्टेन्ट v1.0",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "अन-डिभाइस र क्लाउड एआई समर्थित पूर्ण नेपाली आवाज र एप नियन्त्रण प्रणाली।",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
