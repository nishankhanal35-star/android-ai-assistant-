package com.example.ai

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Build
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream

/**
 * Robust wrapper service around Android's [MediaPlayer] for accepting, caching,
 * and playing audio byte streams (e.g. from ElevenLabs Text-to-Speech API).
 *
 * Handles background audio playback, audio focus management, temporary caching,
 * and lifecycle callbacks cleanly.
 */
class AudioStreamPlayer private constructor() {

    sealed class PlaybackState {
        object Idle : PlaybackState()
        object Preparing : PlaybackState()
        object Playing : PlaybackState()
        object Paused : PlaybackState()
        data class Error(val message: String) : PlaybackState()
        object Completed : PlaybackState()
    }

    private var mediaPlayer: MediaPlayer? = null
    private var audioManager: AudioManager? = null
    private var audioFocusRequest: AudioFocusRequest? = null

    private val _playbackState = MutableStateFlow<PlaybackState>(PlaybackState.Idle)
    val playbackState: StateFlow<PlaybackState> = _playbackState.asStateFlow()

    @Volatile
    private var currentCacheFile: File? = null

    private val audioFocusChangeListener = AudioManager.OnAudioFocusChangeListener { focusChange ->
        when (focusChange) {
            AudioManager.AUDIOFOCUS_LOSS -> {
                Log.d(TAG, "Audio focus lost completely. Stopping playback.")
                stop()
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                Log.d(TAG, "Audio focus lost transiently. Pausing playback.")
                pause()
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                Log.d(TAG, "Audio focus ducking requested.")
                mediaPlayer?.setVolume(0.2f, 0.2f)
            }
            AudioManager.AUDIOFOCUS_GAIN -> {
                Log.d(TAG, "Audio focus gained. Restoring volume/playback.")
                mediaPlayer?.setVolume(1.0f, 1.0f)
            }
        }
    }

    /**
     * Delegates audio byte stream playback directly to [com.example.service.ExoAudioService]
     * for foreground service ExoPlayer playback.
     */
    fun playBytesViaExoService(context: Context, bytes: ByteArray, title: String = "नेपाली आवाज") {
        com.example.service.ExoAudioService.playBytes(context, bytes, title)
    }

    /**
     * Plays audio directly from a [ByteArray] byte stream.
     */
    suspend fun playBytes(
        context: Context,
        bytes: ByteArray,
        onStart: (() -> Unit)? = null,
        onDone: (() -> Unit)? = null,
        onError: ((String) -> Unit)? = null
    ): Boolean = withContext(Dispatchers.IO) {
        return@withContext playStream(context, ByteArrayInputStream(bytes), onStart, onDone, onError)
    }

    /**
     * Accepts an [InputStream] (e.g., from Retrofit [okhttp3.ResponseBody.byteStream]),
     * writes it to a temporary cached audio file, and plays it with proper background
     * audio attributes and focus.
     */
    suspend fun playStream(
        context: Context,
        inputStream: InputStream,
        onStart: (() -> Unit)? = null,
        onDone: (() -> Unit)? = null,
        onError: ((String) -> Unit)? = null
    ): Boolean = withContext(Dispatchers.IO) {
        val tempFile = File(context.cacheDir, "elevenlabs_stream_${System.currentTimeMillis()}.mp3")
        currentCacheFile = tempFile

        return@withContext try {
            _playbackState.value = PlaybackState.Preparing
            FileOutputStream(tempFile).use { output ->
                inputStream.copyTo(output)
                output.flush()
            }

            playFileInternal(context, tempFile, onStart, onDone, onError)
        } catch (e: Exception) {
            Log.e(TAG, "Error writing byte stream to file", e)
            _playbackState.value = PlaybackState.Error("Failed to write audio stream: ${e.message}")
            withContext(Dispatchers.Main) {
                onError?.invoke(e.localizedMessage ?: "Stream write error")
            }
            false
        }
    }

    /**
     * Plays an audio file directly.
     */
    suspend fun playFile(
        context: Context,
        file: File,
        onStart: (() -> Unit)? = null,
        onDone: (() -> Unit)? = null,
        onError: ((String) -> Unit)? = null
    ): Boolean = withContext(Dispatchers.IO) {
        return@withContext playFileInternal(context, file, onStart, onDone, onError)
    }

    private suspend fun playFileInternal(
        context: Context,
        file: File,
        onStart: (() -> Unit)? = null,
        onDone: (() -> Unit)? = null,
        onError: ((String) -> Unit)? = null
    ): Boolean = withContext(Dispatchers.Main) {
        stop()

        if (!file.exists() || file.length() == 0L) {
            Log.e(TAG, "Audio file is invalid or empty: ${file.absolutePath}")
            _playbackState.value = PlaybackState.Error("Invalid audio stream file")
            onError?.invoke("Invalid audio stream file")
            return@withContext false
        }

        audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        requestAudioFocus()

        try {
            val player = MediaPlayer().apply {
                setDataSource(file.absolutePath)

                val audioAttributes = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()

                setAudioAttributes(audioAttributes)
                prepare()

                setOnCompletionListener { mp ->
                    Log.d(TAG, "Audio playback completed cleanly.")
                    _playbackState.value = PlaybackState.Completed
                    abandonAudioFocus()
                    mp.release()
                    if (mediaPlayer == mp) {
                        mediaPlayer = null
                    }
                    cleanupOldCacheFiles(context)
                    onDone?.invoke()
                }

                setOnErrorListener { mp, what, extra ->
                    val errMsg = "MediaPlayer error code: what=$what, extra=$extra"
                    Log.e(TAG, errMsg)
                    _playbackState.value = PlaybackState.Error(errMsg)
                    abandonAudioFocus()
                    mp.release()
                    if (mediaPlayer == mp) {
                        mediaPlayer = null
                    }
                    cleanupOldCacheFiles(context)
                    onError?.invoke(errMsg)
                    true
                }

                start()
            }

            mediaPlayer = player
            _playbackState.value = PlaybackState.Playing
            onStart?.invoke()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start MediaPlayer playback", e)
            _playbackState.value = PlaybackState.Error(e.message ?: "Playback error")
            abandonAudioFocus()
            stop()
            onError?.invoke(e.localizedMessage ?: "Playback error")
            false
        }
    }

    fun pause() {
        try {
            mediaPlayer?.let { player ->
                if (player.isPlaying) {
                    player.pause()
                    _playbackState.value = PlaybackState.Paused
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error pausing player", e)
        }
    }

    fun resume() {
        try {
            mediaPlayer?.let { player ->
                if (_playbackState.value is PlaybackState.Paused) {
                    player.start()
                    _playbackState.value = PlaybackState.Playing
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error resuming player", e)
        }
    }

    fun stop() {
        try {
            abandonAudioFocus()
            mediaPlayer?.let { player ->
                if (player.isPlaying) {
                    player.stop()
                }
                player.release()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping player", e)
        } finally {
            mediaPlayer = null
            _playbackState.value = PlaybackState.Idle
        }
    }

    fun isPlaying(): Boolean {
        return try {
            mediaPlayer?.isPlaying == true
        } catch (e: Exception) {
            false
        }
    }

    private fun requestAudioFocus() {
        val manager = audioManager ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val focusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANT)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setOnAudioFocusChangeListener(audioFocusChangeListener)
                .build()
            audioFocusRequest = focusRequest
            manager.requestAudioFocus(focusRequest)
        } else {
            @Suppress("DEPRECATION")
            manager.requestAudioFocus(
                audioFocusChangeListener,
                AudioManager.STREAM_MUSIC,
                AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK
            )
        }
    }

    private fun abandonAudioFocus() {
        val manager = audioManager ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            audioFocusRequest?.let { focusReq ->
                manager.abandonAudioFocusRequest(focusReq)
            }
            audioFocusRequest = null
        } else {
            @Suppress("DEPRECATION")
            manager.abandonAudioFocus(audioFocusChangeListener)
        }
    }

    private fun cleanupOldCacheFiles(context: Context) {
        try {
            val cacheDir = context.cacheDir
            cacheDir.listFiles { _, name -> name.startsWith("elevenlabs_stream_") }?.forEach { file ->
                if (file != currentCacheFile && System.currentTimeMillis() - file.lastModified() > 60_000) {
                    file.delete()
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to cleanup old cache files", e)
        }
    }

    companion object {
        private const val TAG = "AudioStreamPlayer"

        @Volatile
        private var INSTANCE: AudioStreamPlayer? = null

        fun getInstance(): AudioStreamPlayer {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: AudioStreamPlayer().also { INSTANCE = it }
            }
        }
    }
}
