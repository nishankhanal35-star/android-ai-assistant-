package com.example.data

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys

object Storage {
    private const val PREFS_NAME = "nepali_assistant_prefs"
    private const val KEY_API = "gemini_api_key"
    private const val KEY_AUTOMATION = "automation_mode_full"
    private const val KEY_LISTENING = "listening_mode_wakeword"
    private const val KEY_SPEECH_PITCH = "speech_pitch"
    private const val KEY_SPEECH_RATE = "speech_rate"
    private const val KEY_SERVICE_ACTIVE = "service_active"
    private const val KEY_AI_MODEL = "ai_model"
    private const val KEY_ELEVENLABS_API = "elevenlabs_api_key"
    private const val KEY_ELEVENLABS_VOICE = "elevenlabs_voice_id"
    private const val KEY_USE_ELEVENLABS = "use_elevenlabs"

    private fun getEncryptedPrefs(context: Context): SharedPreferences {
        return try {
            val masterKeyAlias = MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC)
            EncryptedSharedPreferences.create(
                PREFS_NAME,
                masterKeyAlias,
                context,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            Log.e("Storage", "Error creating EncryptedSharedPreferences, fallback to standard", e)
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        }
    }

    fun saveApiKey(context: Context, key: String) {
        getEncryptedPrefs(context).edit().putString(KEY_API, key.trim()).apply()
    }

    fun getApiKey(context: Context): String? {
        val key = getEncryptedPrefs(context).getString(KEY_API, null)
        if (!key.isNullOrBlank()) return key
        return try {
            val field = com.example.BuildConfig::class.java.getField("GEMINI_API_KEY")
            val buildConfigKey = field.get(null) as? String
            if (!buildConfigKey.isNullOrBlank() && buildConfigKey != "MY_GEMINI_API_KEY") buildConfigKey else null
        } catch (e: Exception) {
            null
        }
    }

    fun setAutomationMode(context: Context, isFull: Boolean) {
        getEncryptedPrefs(context).edit().putBoolean(KEY_AUTOMATION, isFull).apply()
    }

    fun isFullAutomation(context: Context): Boolean {
        return getEncryptedPrefs(context).getBoolean(KEY_AUTOMATION, false)
    }

    fun setListeningModeWakeword(context: Context, isWakeword: Boolean) {
        getEncryptedPrefs(context).edit().putBoolean(KEY_LISTENING, isWakeword).apply()
    }

    fun isWakeword(context: Context): Boolean {
        return getEncryptedPrefs(context).getBoolean(KEY_LISTENING, true)
    }

    fun saveSpeechPitch(context: Context, pitch: Float) {
        getEncryptedPrefs(context).edit().putFloat(KEY_SPEECH_PITCH, pitch).apply()
    }

    fun getSpeechPitch(context: Context): Float {
        return getEncryptedPrefs(context).getFloat(KEY_SPEECH_PITCH, 1.0f)
    }

    fun saveSpeechRate(context: Context, rate: Float) {
        getEncryptedPrefs(context).edit().putFloat(KEY_SPEECH_RATE, rate).apply()
    }

    fun getSpeechRate(context: Context): Float {
        return getEncryptedPrefs(context).getFloat(KEY_SPEECH_RATE, 1.0f)
    }

    fun setServiceActive(context: Context, active: Boolean) {
        getEncryptedPrefs(context).edit().putBoolean(KEY_SERVICE_ACTIVE, active).apply()
    }

    fun isServiceActive(context: Context): Boolean {
        return getEncryptedPrefs(context).getBoolean(KEY_SERVICE_ACTIVE, true)
    }

    fun saveAiModel(context: Context, model: String) {
        getEncryptedPrefs(context).edit().putString(KEY_AI_MODEL, model).apply()
    }

    fun getAiModel(context: Context): String {
        return getEncryptedPrefs(context).getString(KEY_AI_MODEL, "gemini-2.5-flash") ?: "gemini-2.5-flash"
    }

    fun saveElevenLabsApiKey(context: Context, key: String) {
        getEncryptedPrefs(context).edit().putString(KEY_ELEVENLABS_API, key.trim()).apply()
    }

    fun getElevenLabsApiKey(context: Context): String? {
        val key = getEncryptedPrefs(context).getString(KEY_ELEVENLABS_API, null)
        if (!key.isNullOrBlank()) return key
        return try {
            val field = com.example.BuildConfig::class.java.getField("ELEVENLABS_API_KEY")
            val buildConfigKey = field.get(null) as? String
            if (!buildConfigKey.isNullOrBlank() && buildConfigKey != "MY_ELEVENLABS_API_KEY") buildConfigKey else null
        } catch (e: Exception) {
            null
        }
    }

    fun saveElevenLabsVoiceId(context: Context, voiceId: String) {
        getEncryptedPrefs(context).edit().putString(KEY_ELEVENLABS_VOICE, voiceId.trim()).apply()
    }

    fun getElevenLabsVoiceId(context: Context): String {
        val voiceId = getEncryptedPrefs(context).getString(KEY_ELEVENLABS_VOICE, null)
        return if (!voiceId.isNullOrBlank()) voiceId else "21m00Tcm4TlvDq8ikWAM"
    }

    fun setUseElevenLabs(context: Context, enabled: Boolean) {
        getEncryptedPrefs(context).edit().putBoolean(KEY_USE_ELEVENLABS, enabled).apply()
    }

    fun isUseElevenLabs(context: Context): Boolean {
        return getEncryptedPrefs(context).getBoolean(KEY_USE_ELEVENLABS, true)
    }
}
