package com.example.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import com.example.data.Storage

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action
        Log.d("BootReceiver", "Received Broadcast Intent Action: $action")
        
        if (action == Intent.ACTION_BOOT_COMPLETED || action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            if (Storage.isServiceActive(context)) {
                try {
                    val serviceIntent = Intent(context, VoiceForegroundService::class.java).apply {
                        this.action = VoiceForegroundService.ACTION_START
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        context.startForegroundService(serviceIntent)
                    } else {
                        context.startService(serviceIntent)
                    }
                    Log.d("BootReceiver", "VoiceForegroundService auto-started on boot")
                } catch (e: Exception) {
                    Log.e("BootReceiver", "Failed to start service on boot", e)
                }
            }
        }
    }
}
