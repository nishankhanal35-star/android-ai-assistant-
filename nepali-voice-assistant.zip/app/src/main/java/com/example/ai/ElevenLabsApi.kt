package com.example.ai

import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Headers
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query

/**
 * Retrofit service definition for ElevenLabs Text-to-Speech API.
 * Provides endpoints for voice synthesis with support for the `eleven_multilingual_v2` model
 * to ensure high-quality Nepali voice synthesis.
 */
interface ElevenLabsApi {

    /**
     * Synthesizes text to speech audio stream.
     *
     * @param voiceId ElevenLabs voice ID parameter.
     * @param apiKey Authentication API key passed via the `xi-api-key` header.
     * @param outputFormat Audio format query option, defaults to "mp3_44100_128".
     * @param request The [ElevenLabsTtsRequest] payload configured with Multilingual v2 model.
     * @param acceptHeader Accept header, defaults to "audio/mpeg".
     * @return [Response] wrapping the [ResponseBody] containing the MP3 audio stream.
     */
    @POST("v1/text-to-speech/{voice_id}")
    @Headers("Content-Type: application/json")
    suspend fun textToSpeech(
        @Path("voice_id") voiceId: String,
        @Header("xi-api-key") apiKey: String,
        @Query("output_format") outputFormat: String = "mp3_44100_128",
        @Body request: ElevenLabsTtsRequest,
        @Header("Accept") acceptHeader: String = "audio/mpeg"
    ): Response<ResponseBody>

    /**
     * Fetches available voices from ElevenLabs.
     */
    @GET("v1/voices")
    suspend fun getVoices(
        @Header("xi-api-key") apiKey: String
    ): Response<ElevenLabsVoicesResponse>

    companion object {
        const val BASE_URL = "https://api.elevenlabs.io/"
        const val DEFAULT_VOICE_ID = "21m00Tcm4TlvDq8ikWAM"
    }
}
