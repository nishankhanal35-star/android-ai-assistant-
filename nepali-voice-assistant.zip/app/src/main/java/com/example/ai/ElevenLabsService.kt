package com.example.ai

import android.content.Context
import android.util.Log
import com.example.data.Storage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.util.concurrent.TimeUnit

object ElevenLabsService {
    private const val TAG = "ElevenLabsService"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    private val retrofit = Retrofit.Builder()
        .baseUrl(ElevenLabsApi.BASE_URL)
        .client(okHttpClient)
        .addConverterFactory(MoshiConverterFactory.create())
        .build()

    val api: ElevenLabsApi = retrofit.create(ElevenLabsApi::class.java)

    private val audioPlayer = AudioStreamPlayer.getInstance()

    suspend fun synthesizeAndPlay(
        context: Context,
        text: String,
        onStart: (() -> Unit)? = null,
        onDone: (() -> Unit)? = null,
        onError: ((String) -> Unit)? = null
    ): Boolean = withContext(Dispatchers.IO) {
        val apiKey = Storage.getElevenLabsApiKey(context)
        if (apiKey.isNullOrBlank()) {
            Log.w(TAG, "ElevenLabs API key is missing or blank.")
            withContext(Dispatchers.Main) {
                onError?.invoke("ElevenLabs API key is missing.")
            }
            return@withContext false
        }

        val cleanedText = cleanTextForNepaliTts(text)
        if (cleanedText.isBlank()) {
            withContext(Dispatchers.Main) {
                onDone?.invoke()
            }
            return@withContext true
        }

        val voiceId = Storage.getElevenLabsVoiceId(context).ifBlank { ElevenLabsApi.DEFAULT_VOICE_ID }

        try {
            val ttsRequest = ElevenLabsTtsRequest(
                text = cleanedText,
                modelId = ElevenLabsTtsRequest.MODEL_MULTILINGUAL_V2,
                voiceSettings = ElevenLabsVoiceSettings(
                    stability = 0.45,
                    similarityBoost = 0.85,
                    style = 0.05,
                    useSpeakerBoost = true
                )
            )

            val response = api.textToSpeech(
                voiceId = voiceId,
                apiKey = apiKey,
                outputFormat = "mp3_44100_128",
                request = ttsRequest
            )

            if (!response.isSuccessful) {
                val errorBody = response.errorBody()?.string() ?: ""
                Log.e(TAG, "ElevenLabs API request failed with code ${response.code()}: $errorBody")
                withContext(Dispatchers.Main) {
                    onError?.invoke("ElevenLabs error (${response.code()})")
                }
                return@withContext false
            }

            val responseBody = response.body() ?: throw Exception("Empty response body from ElevenLabs API")
            
            // Pass the input stream directly to AudioStreamPlayer for clean playback & background audio handling
            return@withContext responseBody.byteStream().use { inputStream ->
                audioPlayer.playStream(
                    context = context,
                    inputStream = inputStream,
                    onStart = onStart,
                    onDone = onDone,
                    onError = onError
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "ElevenLabs synthesis failed with exception", e)
            withContext(Dispatchers.Main) {
                onError?.invoke(e.localizedMessage ?: "Network error")
            }
            return@withContext false
        }
    }

    fun stopPlayback() {
        audioPlayer.stop()
    }

    fun isPlaying(): Boolean {
        return audioPlayer.isPlaying()
    }

    private fun cleanTextForNepaliTts(rawText: String): String {
        return rawText
            .replace(Regex("```[\\s\\S]*?```"), "")
            .replace(Regex("\\[([^\\]]+)\\]\\([^\\)]+\\)"), "$1")
            .replace("**", "")
            .replace("*", "")
            .replace("#", "")
            .replace("`", "")
            .replace("~", "")
            .replace(Regex("(?m)^\\s*[-•+]\\s*"), "")
            // Replaces multiple types of western trailing punctuation spaces safely back to Devanagari ends (।)
            .replace(Regex("([\\u0900-\\u097F])\\s*\\.\\s*"), "$1। ")
            .replace(Regex("([\\u0900-\\u097F])\\s*\\?\\s*"), "$1? ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }
}
