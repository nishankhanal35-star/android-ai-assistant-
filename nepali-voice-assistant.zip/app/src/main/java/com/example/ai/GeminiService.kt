package com.example.ai

import android.content.Context
import android.util.Log
import com.example.data.Storage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

data class AssistantResult(
    val reply: String,
    val action: String, // OPEN_YOUTUBE_SEARCH, OPEN_APP, MAKE_CALL, SEND_SMS, SEND_WHATSAPP, SET_ALARM, GET_TIME, GET_DATE, GENERAL_CHAT
    val query: String = "",
    val target: String = "",
    val message: String = ""
)

object GeminiService {
    private const val TAG = "GeminiService"
    
    private val client = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private const val SYSTEM_INSTRUCTION = """
You are an intelligent, fluent, highly capable Nepali Voice Assistant named 'Nepali Voice Assistant' (नेपाली भोइस असिस्टेन्ट).
Analyze the user's voice command in Nepali (or English) and respond ONLY with a strict JSON object matching this schema:
{
  "reply": "Natural, polite response spoken in Nepali (Devanagari script)",
  "action": "Action enum string",
  "query": "Search query or video name if applicable",
  "target": "Target contact name, phone number, or app name if applicable",
  "message": "Message body to send if applicable"
}

Allowed 'action' values:
- "OPEN_YOUTUBE_SEARCH": User wants to search/play something on YouTube (e.g. "युट्युबमा गीत बजाऊ", "play music on YouTube"). Set 'query'.
- "OPEN_APP": User wants to open an installed app (e.g. "युट्युब खोल", "फेसबुक खोल", "ग्यालरी खोल"). Set 'target' to app name.
- "MAKE_CALL": User wants to call someone (e.g. "रामलाई फोन गर", "९८०००००००० मा कल गर"). Set 'target' to contact/number.
- "SEND_SMS": User wants to send an SMS (e.g. "हरिलाई सन्देश पठाऊ"). Set 'target' and 'message'.
- "SEND_WHATSAPP": User wants to send a WhatsApp message (e.g. "व्हाट्सएपमा सन्देश पठाऊ"). Set 'target' and 'message'.
- "SET_ALARM": User wants an alarm or reminder. Set 'message' or time.
- "GET_TIME": User asks for current time.
- "GET_DATE": User asks for current date.
- "GENERAL_CHAT": General question or conversation.

IMPORTANT: Your 'reply' MUST be in natural, correct Nepali Devanagari script. Do NOT include markdown code fences or raw backticks around the JSON.
"""

    suspend fun processCommand(context: Context, command: String): AssistantResult = withContext(Dispatchers.IO) {
        val apiKey = Storage.getApiKey(context)
        val model = Storage.getAiModel(context)

        if (!apiKey.isNullOrBlank()) {
            try {
                val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"
                
                val promptText = "User Command: \"$command\"\nCurrent Time: ${SimpleDateFormat("HH:mm, EEEE, dd MMMM yyyy", Locale("ne", "NP")).format(Date())}"

                val jsonPayload = JSONObject().apply {
                    put("contents", org.json.JSONArray().apply {
                        put(JSONObject().apply {
                            put("role", "user")
                            put("parts", org.json.JSONArray().apply {
                                put(JSONObject().put("text", "$SYSTEM_INSTRUCTION\n\n$promptText"))
                            })
                        })
                    })
                    put("generationConfig", JSONObject().apply {
                        put("temperature", 0.2)
                        put("responseMimeType", "application/json")
                    })
                }

                val requestBody = jsonPayload.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
                val request = Request.Builder()
                    .url(url)
                    .post(requestBody)
                    .build()

                client.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        val respBody = response.body?.string() ?: ""
                        val rootJson = JSONObject(respBody)
                        val candidates = rootJson.optJSONArray("candidates")
                        if (candidates != null && candidates.length() > 0) {
                            val firstCand = candidates.getJSONObject(0)
                            val content = firstCand.optJSONObject("content")
                            val parts = content?.optJSONArray("parts")
                            if (parts != null && parts.length() > 0) {
                                val textResult = parts.getJSONObject(0).optString("text", "")
                                val parsed = parseJsonResponse(textResult)
                                if (parsed != null) return@withContext parsed
                            }
                        }
                    } else {
                        Log.w(TAG, "Gemini API HTTP Error: ${response.code} - ${response.message}")
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error executing Gemini API call, using rule fallback", e)
            }
        }

        // Resilient Offline Rule-based Fallback Parser
        return@withContext parseRuleFallback(command)
    }

    private fun parseJsonResponse(rawJson: String): AssistantResult? {
        return try {
            val cleaned = rawJson.trim()
                .removePrefix("```json")
                .removePrefix("```")
                .removeSuffix("```")
                .trim()
            val json = JSONObject(cleaned)
            AssistantResult(
                reply = json.optString("reply", "हुन्छ, मैले बुझेँ।"),
                action = json.optString("action", "GENERAL_CHAT"),
                query = json.optString("query", ""),
                target = json.optString("target", ""),
                message = json.optString("message", "")
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed to parse JSON response: $rawJson", e)
            null
        }
    }

    fun parseRuleFallback(command: String): AssistantResult {
        val lower = command.lowercase(Locale.ROOT)
        val trimmed = command.trim()

        return when {
            lower.contains("युट्युब") || lower.contains("youtube") -> {
                val query = trimmed.replace("युट्युबमा", "")
                    .replace("युट्युब", "")
                    .replace("youtube", "")
                    .replace("बजाऊ", "")
                    .replace("खोल", "")
                    .replace("खोज", "")
                    .replace("play", "")
                    .replace("search", "")
                    .trim()
                if (query.length > 1) {
                    AssistantResult(
                        reply = "युट्युबमा '$query' खोज्दैछौँ।",
                        action = "OPEN_YOUTUBE_SEARCH",
                        query = query
                    )
                } else {
                    AssistantResult(
                        reply = "युट्युब एप खोल्दैछु।",
                        action = "OPEN_APP",
                        target = "YouTube"
                    )
                }
            }

            lower.contains("फोन") || lower.contains("कल") || lower.contains("call") -> {
                val target = trimmed.replace("लाई", "")
                    .replace("फोन", "")
                    .replace("गर", "")
                    .replace("कल", "")
                    .replace("call", "")
                    .trim()
                AssistantResult(
                    reply = if (target.isNotBlank()) "'$target' लाई फोन गर्दैछु।" else "फोन डायलर खोल्दैछु।",
                    action = "MAKE_CALL",
                    target = target
                )
            }

            lower.contains("व्हाट्सएप") || lower.contains("whatsapp") -> {
                AssistantResult(
                    reply = "व्हाट्सएप खोल्दैछु।",
                    action = "SEND_WHATSAPP",
                    target = "",
                    message = trimmed
                )
            }

            lower.contains("सन्देश") || lower.contains("म्यासेज") || lower.contains("sms") -> {
                AssistantResult(
                    reply = "सन्देश पठाउन मेसेज एप खोल्दैछु।",
                    action = "SEND_SMS",
                    message = trimmed
                )
            }

            lower.contains("कति बज्यो") || lower.contains("समय") || lower.contains("time") -> {
                val currentTime = SimpleDateFormat("hh:mm a", Locale("ne", "NP")).format(Date())
                AssistantResult(
                    reply = "अहिले $currentTime बज्यो।",
                    action = "GET_TIME"
                )
            }

            lower.contains("मिति") || lower.contains("गते") || lower.contains("date") -> {
                val currentDate = SimpleDateFormat("EEEE, dd MMMM yyyy", Locale("ne", "NP")).format(Date())
                AssistantResult(
                    reply = "आजको मिति $currentDate हो।",
                    action = "GET_DATE"
                )
            }

            lower.contains("खोल") || lower.contains("open") -> {
                val appName = trimmed.replace("खोल", "").replace("open", "").trim()
                AssistantResult(
                    reply = "'$appName' एप खोल्दैछु।",
                    action = "OPEN_APP",
                    target = appName
                )
            }

            else -> {
                AssistantResult(
                    reply = "नमस्ते! म तपाईंको नेपाली भोइस असिस्टेन्ट हुँ। म युट्युब भिडियो खोज्न, फोन गर्न र एपहरू खोल्न मद्दत गर्न सक्छु।",
                    action = "GENERAL_CHAT"
                )
            }
        }
    }
}
