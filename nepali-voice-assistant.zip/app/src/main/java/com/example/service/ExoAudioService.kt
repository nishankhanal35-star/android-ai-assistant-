package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.ByteArrayDataSource
import androidx.media3.datasource.DataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import com.example.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream

/**
 * ExoPlayer-based Android Foreground Service that accepts audio byte streams,
 * manages custom low-latency audio buffering, and guarantees clean, uninterrupted
 * audio playback while the app is in the background.
 */
class ExoAudioService : Service() {

    sealed class ExoPlaybackState {
        object Idle : ExoPlaybackState()
        object Buffering : ExoPlaybackState()
        object Playing : ExoPlaybackState()
        object Paused : ExoPlaybackState()
        object Completed : ExoPlaybackState()
        data class Error(val message: String) : ExoPlaybackState()
    }

    inner class LocalBinder : Binder() {
        fun getService(): ExoAudioService = this@ExoAudioService
    }

    private val binder = LocalBinder()
    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private var exoPlayer: ExoPlayer? = null

    private val _playbackState = MutableStateFlow<ExoPlaybackState>(ExoPlaybackState.Idle)
    val playbackState: StateFlow<ExoPlaybackState> = _playbackState.asStateFlow()

    @Volatile
    private var currentTitle: String = "नेपाली आवाज विवरण"

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        initializeExoPlayer()
        Log.d(TAG, "ExoAudioService created & initialized")
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PLAY_BYTES -> {
                val bytes = intent.getByteArrayExtra(EXTRA_BYTE_ARRAY)
                val title = intent.getStringExtra(EXTRA_TITLE) ?: "नेपाली आवाज"
                if (bytes != null && bytes.isNotEmpty()) {
                    playByteStream(bytes, title)
                }
            }
            ACTION_PAUSE -> pause()
            ACTION_RESUME -> resume()
            ACTION_STOP -> stopPlayback()
        }
        return START_NOT_STICKY
    }

    /**
     * Initializes ExoPlayer with custom load control for low-latency audio stream buffering
     * and automatic audio focus handling.
     */
    private fun initializeExoPlayer() {
        if (exoPlayer != null) return

        // Configure custom load control for optimal byte stream buffering
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(
                15_000, // Minimum buffer before stopping loading (15s)
                50_000, // Maximum buffer capacity (50s)
                250,    // Buffer required to start playback (250ms for instant start)
                500     // Buffer required to resume after rebuffering (500ms)
            )
            .setPrioritizeTimeOverSizeThresholds(true)
            .build()

        // Configure AudioAttributes for speech/voice playback and focus handling
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_SPEECH)
            .build()

        exoPlayer = ExoPlayer.Builder(this)
            .setLoadControl(loadControl)
            .setAudioAttributes(audioAttributes, true /* handleAudioFocus */)
            .setHandleAudioBecomingNoisy(true)
            .build()
            .apply {
                addListener(object : Player.Listener {
                    override fun onPlaybackStateChanged(playbackState: Int) {
                        when (playbackState) {
                            Player.STATE_BUFFERING -> {
                                _playbackState.value = ExoPlaybackState.Buffering
                                updateNotification("अडियो बफरिङ हुँदैछ...")
                            }
                            Player.STATE_READY -> {
                                if (isPlaying) {
                                    _playbackState.value = ExoPlaybackState.Playing
                                    updateNotification(currentTitle)
                                } else {
                                    _playbackState.value = ExoPlaybackState.Paused
                                }
                            }
                            Player.STATE_ENDED -> {
                                _playbackState.value = ExoPlaybackState.Completed
                                Log.d(TAG, "ExoPlayer finished playback")
                                stopForegroundService()
                            }
                            Player.STATE_IDLE -> {
                                _playbackState.value = ExoPlaybackState.Idle
                            }
                        }
                    }

                    override fun onIsPlayingChanged(isPlaying: Boolean) {
                        if (isPlaying) {
                            _playbackState.value = ExoPlaybackState.Playing
                            updateNotification(currentTitle)
                        } else if (_playbackState.value is ExoPlaybackState.Playing) {
                            _playbackState.value = ExoPlaybackState.Paused
                        }
                    }

                    override fun onPlayerError(error: PlaybackException) {
                        val errorMsg = "ExoPlayer Error: ${error.message}"
                        Log.e(TAG, errorMsg, error)
                        _playbackState.value = ExoPlaybackState.Error(errorMsg)
                        stopForegroundService()
                    }
                })
            }
    }

    /**
     * Accepts a raw byte array stream and buffers/plays it using ExoPlayer in the background.
     */
    fun playByteStream(bytes: ByteArray, title: String = "नेपाली आवाज विवरण") {
        currentTitle = title
        startForegroundServiceNotification(title)

        serviceScope.launch(Dispatchers.IO) {
            try {
                val byteArrayDataSource = ByteArrayDataSource(bytes)
                val dataSourceFactory = DataSource.Factory { byteArrayDataSource }
                val mediaItem = MediaItem.fromUri("bytes://elevenlabs_stream_${System.currentTimeMillis()}")
                val mediaSource = ProgressiveMediaSource.Factory(dataSourceFactory)
                    .createMediaSource(mediaItem)

                withContext(Dispatchers.Main) {
                    exoPlayer?.let { player ->
                        player.stop()
                        player.setMediaSource(mediaSource)
                        player.prepare()
                        player.playWhenReady = true
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to stream bytes into ExoPlayer", e)
                withContext(Dispatchers.Main) {
                    _playbackState.value = ExoPlaybackState.Error("Byte stream playback error: ${e.message}")
                    stopForegroundService()
                }
            }
        }
    }

    /**
     * Accepts an [InputStream] (e.g. from Retrofit network response body), buffers it to byte storage,
     * and streams it seamlessly through ExoPlayer.
     */
    fun playInputStream(inputStream: InputStream, title: String = "नेपाली आवाज विवरण") {
        currentTitle = title
        startForegroundServiceNotification(title)

        serviceScope.launch(Dispatchers.IO) {
            try {
                val buffer = ByteArrayOutputStream()
                inputStream.use { input ->
                    input.copyTo(buffer)
                }
                val bytes = buffer.toByteArray()
                withContext(Dispatchers.Main) {
                    playByteStream(bytes, title)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to process InputStream for ExoPlayer", e)
                withContext(Dispatchers.Main) {
                    _playbackState.value = ExoPlaybackState.Error("Stream buffer error: ${e.message}")
                    stopForegroundService()
                }
            }
        }
    }

    /**
     * Accepts a local file reference and plays it through ExoPlayer.
     */
    fun playFile(file: File, title: String = "नेपाली आवाज विवरण") {
        if (!file.exists() || file.length() == 0L) {
            Log.e(TAG, "Audio file does not exist or is empty")
            _playbackState.value = ExoPlaybackState.Error("Invalid audio file")
            return
        }

        currentTitle = title
        startForegroundServiceNotification(title)

        val mediaItem = MediaItem.fromUri(file.toURI().toString())
        exoPlayer?.let { player ->
            player.stop()
            player.setMediaItem(mediaItem)
            player.prepare()
            player.playWhenReady = true
        }
    }

    fun pause() {
        exoPlayer?.pause()
        _playbackState.value = ExoPlaybackState.Paused
    }

    fun resume() {
        exoPlayer?.play()
        _playbackState.value = ExoPlaybackState.Playing
    }

    fun stopPlayback() {
        exoPlayer?.stop()
        _playbackState.value = ExoPlaybackState.Idle
        stopForegroundService()
    }

    fun isPlaying(): Boolean = exoPlayer?.isPlaying == true

    private fun startForegroundServiceNotification(title: String) {
        val notification = buildNotification(title)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun updateNotification(title: String) {
        val notification = buildNotification(title)
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(NOTIFICATION_ID, notification)
    }

    private fun buildNotification(contentText: String): Notification {
        val stopIntent = Intent(this, ExoAudioService::class.java).apply { action = ACTION_STOP }
        val stopPendingIntent = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val pauseIntent = Intent(this, ExoAudioService::class.java).apply {
            action = if (isPlaying()) ACTION_PAUSE else ACTION_RESUME
        }
        val pausePendingIntent = PendingIntent.getService(
            this, 1, pauseIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("आवाज सेवा (Voice Service)")
            .setContentText(contentText)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(
                if (isPlaying()) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play,
                if (isPlaying()) "Pause" else "Play",
                pausePendingIntent
            )
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stopPendingIntent)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "ExoPlayer Audio Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Handles background ExoPlayer byte stream audio playback"
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    private fun stopForegroundService() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
    }

    override fun onDestroy() {

        exoPlayer?.release()
        exoPlayer = null
        super.onDestroy()
        Log.d(TAG, "ExoAudioService destroyed")
    }

    companion object {
        private const val TAG = "ExoAudioService"
        const val CHANNEL_ID = "exo_audio_playback_channel"
        const val NOTIFICATION_ID = 2002

        const val ACTION_PLAY_BYTES = "com.example.action.EXO_PLAY_BYTES"
        const val ACTION_PAUSE = "com.example.action.EXO_PAUSE"
        const val ACTION_RESUME = "com.example.action.EXO_RESUME"
        const val ACTION_STOP = "com.example.action.EXO_STOP"

        const val EXTRA_BYTE_ARRAY = "extra_byte_array"
        const val EXTRA_TITLE = "extra_title"

        fun playBytes(context: Context, bytes: ByteArray, title: String = "नेपाली आवाज") {
            val intent = Intent(context, ExoAudioService::class.java).apply {
                action = ACTION_PLAY_BYTES
                putExtra(EXTRA_BYTE_ARRAY, bytes)
                putExtra(EXTRA_TITLE, title)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }
}
