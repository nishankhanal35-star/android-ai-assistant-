package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.ai.VoiceState
import kotlin.math.sin

@Composable
fun VoiceWaveform(
    voiceState: VoiceState,
    rmsDb: Float,
    modifier: Modifier = Modifier
) {
    val phaseAnim = remember { Animatable(0f) }

    LaunchedEffect(voiceState) {
        if (voiceState is VoiceState.Listening || voiceState is VoiceState.Speaking) {
            phaseAnim.animateTo(
                targetValue = (2 * Math.PI).toFloat(),
                animationSpec = infiniteRepeatable(
                    animation = tween(durationMillis = 1200, easing = FastOutSlowInEasing),
                    repeatMode = RepeatMode.Restart
                )
            )
        } else {
            phaseAnim.snapTo(0f)
        }
    }

    val primaryColor = MaterialTheme.colorScheme.primary
    val secondaryColor = MaterialTheme.colorScheme.secondary
    val tertiaryColor = MaterialTheme.colorScheme.tertiary

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(80.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxWidth().height(80.dp)) {
            val width = size.width
            val height = size.height
            val centerY = height / 2f

            val isActive = voiceState is VoiceState.Listening || voiceState is VoiceState.Speaking
            val baseAmplitude = if (isActive) {
                val dbNorm = (rmsDb.coerceIn(0f, 10f) / 10f) * 25.dp.toPx()
                (12.dp.toPx() + dbNorm)
            } else {
                3.dp.toPx()
            }

            val barsCount = 32
            val spacing = width / barsCount

            for (i in 0 until barsCount) {
                val x = i * spacing + spacing / 2
                val phase = phaseAnim.value + i * 0.2f
                val waveHeight = baseAmplitude * (0.4f + 0.6f * sin(phase))

                val barColor: Color = when (i % 3) {
                    0 -> primaryColor
                    1 -> secondaryColor
                    else -> tertiaryColor
                }.copy(alpha = if (isActive) 0.85f else 0.3f)

                drawLine(
                    color = barColor,
                    start = Offset(x, centerY - waveHeight),
                    end = Offset(x, centerY + waveHeight),
                    strokeWidth = 6.dp.toPx(),
                    cap = androidx.compose.ui.graphics.StrokeCap.Round
                )
            }
        }
    }
}
