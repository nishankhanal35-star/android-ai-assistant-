package com.example.ai

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.util.Log
import androidx.core.content.ContextCompat
import com.example.data.Storage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Locale

sealed class VoiceState {
    object Idle : VoiceState()
    object Listening : VoiceState()
    data class Processing(val recognizedText: String) : VoiceState()
    data class Speaking(val text: String) : VoiceState()
    data class Error(val message: String) : VoiceState()
}

class VoiceManager private constructor(private val context: Context) : TextToSpeech.OnInitListener {

    private val appContext: Context = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        context.applicationContext.createAttributionContext("default")
    } else {
        context.applicationContext
    }

    private var tts: TextToSpeech? = null
    private var isTtsReady = false
    private var speechRecognizer: SpeechRecognizer? = null

    private val _voiceState = MutableStateFlow<VoiceState>(VoiceState.Idle)
    val voiceState: StateFlow<VoiceState> = _voiceState.asStateFlow()

    private val _rmsDb = MutableStateFlow(0f)
    val rmsDb: StateFlow<Float> = _rmsDb.asStateFlow()

    private var onResultListener: ((String) -> Unit)? = null

    companion object {
        private const val TAG = "VoiceManager"
        @Volatile
        private var INSTANCE: VoiceManager? = null

        fun getInstance(context: Context): VoiceManager {
            return INSTANCE ?: synchronized(this) {
                val instance = VoiceManager(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }

    init {
        initTts()
    }

    private fun initTts() {
        if (tts == null) {
            tts = TextToSpeech(appContext, this)
        }
    }

    private var isNepaliSupportedInNativeTts = false

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val nepaliLocale = Locale("ne", "NP")
            var result = tts?.setLanguage(nepaliLocale)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                result = tts?.setLanguage(Locale("ne"))
            }

            if (result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED) {
                isNepaliSupportedInNativeTts = true
                Log.i(TAG, "Native Android Nepali TTS initialized successfully")
            } else {
                isNepaliSupportedInNativeTts = false
                Log.w(TAG, "Native Android Nepali TTS engine not supported on this device. ElevenLabs recommended for human-level voice.")
            }
            isTtsReady = true
            applyTtsSettings()
        } else {
            Log.e(TAG, "TextToSpeech Initialization Failed!")
        }
    }

    fun applyTtsSettings() {
        if (isTtsReady) {
            tts?.setPitch(Storage.getSpeechPitch(context))
            tts?.setSpeechRate(Storage.getSpeechRate(context))
        }
    }

    fun speak(text: String, onDone: (() -> Unit)? = null) {
        stopSpeaking()
        _voiceState.value = VoiceState.Speaking(text)

        val useElevenLabs = Storage.isUseElevenLabs(context)
        val elevenKey = Storage.getElevenLabsApiKey(context)

        if (useElevenLabs && !elevenKey.isNullOrBlank()) {
            CoroutineScope(Dispatchers.Main).launch {
                val success = ElevenLabsService.synthesizeAndPlay(
                    context = context,
                    text = text,
                    onStart = {
                        _voiceState.value = VoiceState.Speaking(text)
                    },
                    onDone = {
                        _voiceState.value = VoiceState.Idle
                        onDone?.invoke()
                    },
                    onError = { err ->
                        Log.w(TAG, "ElevenLabs TTS failed ($err), falling back to native Android TTS")
                        speakWithAndroidTts(text, onDone)
                    }
                )
                if (!success) {
                    Log.w(TAG, "ElevenLabs returned false, executing fallback")
                }
            }
        } else {
            speakWithAndroidTts(text, onDone)
        }
    }

    private fun speakWithAndroidTts(text: String, onDone: (() -> Unit)? = null) {
        initTts()
        applyTtsSettings()

        val isDevanagariText = text.any { it in '\u0900'..'\u097F' }
        if (isDevanagariText && !isNepaliSupportedInNativeTts) {
            Log.w(TAG, "Native Android TTS lacks Nepali language support. Avoiding English TTS fallback for Devanagari text.")
            _voiceState.value = VoiceState.Error("अन-डिभाइस Nepali TTS उपलब्ध छैन। इलेभेनल्याब्स (ElevenLabs) API प्रयोग गर्नुहोस्।")
            Handler(Looper.getMainLooper()).postDelayed({
                _voiceState.value = VoiceState.Idle
                onDone?.invoke()
            }, 2500)
            return
        }

        _voiceState.value = VoiceState.Speaking(text)

        if (isTtsReady) {
            val params = Bundle()
            val utteranceId = "utt_${System.currentTimeMillis()}"

            tts?.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _voiceState.value = VoiceState.Speaking(text)
                }

                override fun onDone(utteranceId: String?) {
                    Handler(Looper.getMainLooper()).post {
                        _voiceState.value = VoiceState.Idle
                        onDone?.invoke()
                    }
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    Handler(Looper.getMainLooper()).post {
                        _voiceState.value = VoiceState.Idle
                        onDone?.invoke()
                    }
                }
            })

            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
        } else {
            Log.w(TAG, "TTS not ready yet")
            Handler(Looper.getMainLooper()).postDelayed({
                _voiceState.value = VoiceState.Idle
                onDone?.invoke()
            }, 1000)
        }
    }

    fun stopSpeaking() {
        ElevenLabsService.stopPlayback()
        if (tts?.isSpeaking == true) {
            tts?.stop()
        }
        if (_voiceState.value is VoiceState.Speaking) {
            _voiceState.value = VoiceState.Idle
        }
    }

    fun startListening(onResult: (String) -> Unit) {
        stopSpeaking()
        this.onResultListener = onResult

        if (ContextCompat.checkSelfPermission(appContext, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Log.e(TAG, "RECORD_AUDIO permission missing before startListening")
            _voiceState.value = VoiceState.Error("माइक्रोफोन अनुमति आवश्यक छ।")
            return
        }

        if (!SpeechRecognizer.isRecognitionAvailable(appContext)) {
            Log.e(TAG, "Speech Recognition is not available on this device")
            _voiceState.value = VoiceState.Error("नेपाली आवाज पहिचान प्रणाली उपलब्ध छैन।")
            return
        }

        try {
            stopListening()

            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(appContext).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        Log.d(TAG, "SpeechRecognizer Ready")
                        _voiceState.value = VoiceState.Listening
                    }

                    override fun onBeginningOfSpeech() {
                        Log.d(TAG, "Speech Beginning")
                    }

                    override fun onRmsChanged(rmsdB: Float) {
                        _rmsDb.value = rmsdB
                    }

                    override fun onBufferReceived(buffer: ByteArray?) {}

                    override fun onEndOfSpeech() {
                        Log.d(TAG, "Speech Ended")
                    }

                    override fun onError(error: Int) {
                        val errorMessage = getSpeechErrorString(error)
                        Log.w(TAG, "SpeechRecognizer Error: $error - $errorMessage")
                        _voiceState.value = VoiceState.Error(errorMessage)
                        _rmsDb.value = 0f
                    }

                    override fun onResults(results: Bundle?) {
                        _rmsDb.value = 0f
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        if (!matches.isNullOrEmpty()) {
                            val recognizedText = matches[0]
                            Log.d(TAG, "Recognized Speech: $recognizedText")
                            _voiceState.value = VoiceState.Processing(recognizedText)
                            onResultListener?.invoke(recognizedText)
                        } else {
                            _voiceState.value = VoiceState.Error("कुनै आवाज सुनिएन।")
                        }
                    }

                    override fun onPartialResults(partialResults: Bundle?) {
                        val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        if (!matches.isNullOrEmpty()) {
                            _voiceState.value = VoiceState.Processing(matches[0])
                        }
                    }

                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ne-NP")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ne-NP")
                putExtra("android.speech.extra.EXTRA_ADDITIONAL_LANGUAGES", arrayOf("ne-NP", "en-US"))
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }

            speechRecognizer?.startListening(intent)
            _voiceState.value = VoiceState.Listening

        } catch (e: Exception) {
            Log.e(TAG, "Exception starting speech recognizer", e)
            _voiceState.value = VoiceState.Error("स्पीच रिकग्नाइजर सुरु गर्न सकिएन।")
        }
    }

    fun stopListening() {
        try {
            speechRecognizer?.cancel()
            speechRecognizer?.destroy()
            speechRecognizer = null
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping recognizer", e)
        }
        if (_voiceState.value is VoiceState.Listening) {
            _voiceState.value = VoiceState.Idle
        }
    }

    fun destroy() {
        stopListening()
        stopSpeaking()
        tts?.shutdown()
        tts = null
    }

    private fun getSpeechErrorString(errorCode: Int): String {
        return when (errorCode) {
            SpeechRecognizer.ERROR_AUDIO -> "अडियो रेकर्डिङ त्रुटि।"
            SpeechRecognizer.ERROR_CLIENT -> "ग्राहक तर्फ त्रुटि भयो।"
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "माइक्रोफोन अनुमति आवश्यक छ।"
            SpeechRecognizer.ERROR_NETWORK -> "इन्टरनेट जडान भएन।"
            SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "इन्टरनेट समय समाप्त भयो।"
            SpeechRecognizer.ERROR_NO_MATCH -> "कुनै आवाज बुझिएन, पुनः प्रयास गर्नुहोस्।"
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "आवाज पहिचानकर्ता व्यस्त छ।"
            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "तपाईंले केही बोल्नुभएन।"
            else -> "त्रुटि भयो ($errorCode)।"
        }
    }
}
