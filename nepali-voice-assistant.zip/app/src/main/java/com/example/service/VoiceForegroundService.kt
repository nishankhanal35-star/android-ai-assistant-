package com.example.service

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.ai.GeminiService
import com.example.ai.VoiceManager
import com.example.data.Storage
import com.example.data.db.AppDatabase
import com.example.data.db.ConversationEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class VoiceForegroundService : Service() {

    companion object {
        private const val TAG = "VoiceForegroundService"
        private const val CHANNEL_ID = "nepali_voice_assistant_channel"
        private const val NOTIFICATION_ID = 2001
        
        const val ACTION_START = "com.example.action.START_SERVICE"
        const val ACTION_STOP = "com.example.action.STOP_SERVICE"
        const val ACTION_LISTEN = "com.example.action.LISTEN_NOW"

        @Volatile
        var isRunning = false
            private set
    }

    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private lateinit var voiceManager: VoiceManager

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        voiceManager = VoiceManager.getInstance(this)
        isRunning = true
        Storage.setServiceActive(this, true)
        
        // Schedule watchdog to ensure high resilience
        ServiceWatchdog.scheduleWatchdog(this)
        Log.d(TAG, "VoiceForegroundService Created")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_LISTEN -> {
                triggerVoiceListening()
            }
        }

        val notification = buildNotification("नेपाली भोइस असिस्टेन्ट सक्रिय छ")
        
        val hasMicPermission = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                var foregroundType = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
                if (hasMicPermission) {
                    foregroundType = foregroundType or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                }
                
                try {
                    startForeground(NOTIFICATION_ID, notification, foregroundType)
                } catch (e: Exception) {
                    Log.e(TAG, "Failed startForeground with type $foregroundType, trying fallback", e)
                    try {
                        startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
                    } catch (e2: Exception) {
                        Log.e(TAG, "Fallback startForeground failed", e2)
                    }
                }
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed startForeground completely", e)
        }

        return START_STICKY
    }

    fun triggerVoiceListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Log.w(TAG, "Cannot trigger voice listening: RECORD_AUDIO permission missing")
            return
        }
        voiceManager.startListening { recognizedText ->
            processUserVoiceText(recognizedText)
        }
    }

    private fun processUserVoiceText(text: String) {
        serviceScope.launch {
            val dao = AppDatabase.getInstance(applicationContext).conversationDao()
            dao.insertConversation(
                ConversationEntity(
                    speaker = "user",
                    messageText = text
                )
            )

            // Call Gemini API or offline parser
            val assistantResult = GeminiService.processCommand(applicationContext, text)

            // Execute requested action
            val actionSuccess = com.example.actions.ActionDispatcher.executeAction(applicationContext, assistantResult)

            // Insert Assistant response into DB
            dao.insertConversation(
                ConversationEntity(
                    speaker = "assistant",
                    messageText = assistantResult.reply,
                    actionType = assistantResult.action,
                    actionDetails = "Target: ${assistantResult.target}, Query: ${assistantResult.query}",
                    isSuccess = actionSuccess
                )
            )

            // Speak response via TTS
            voiceManager.speak(assistantResult.reply)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        Storage.setServiceActive(this, false)
        Log.d(TAG, "VoiceForegroundService Destroyed")
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "Nepali Voice Assistant Service"
            val descriptionText = "Persistent service for background speech commands"
            val importance = NotificationManager.IMPORTANCE_LOW
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
            }
            val notificationManager: NotificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(statusText: String): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this, 0, openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val listenIntent = Intent(this, VoiceForegroundService::class.java).apply {
            action = ACTION_LISTEN
        }
        val listenPendingIntent = PendingIntent.getService(
            this, 1, listenIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, VoiceForegroundService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this, 2, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("नेपाली भोइस असिस्टेन्ट")
            .setContentText(statusText)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(android.R.drawable.ic_btn_speak_now, "बोल्नुहोस्", listenPendingIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "बन्द गर्नुहोस्", stopPendingIntent)
            .build()
    }
}
