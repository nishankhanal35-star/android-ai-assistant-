package com.example.actions

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import android.widget.Toast
import com.example.ai.AssistantResult
import com.example.data.Storage
import com.example.service.MyAccessibilityService

object ActionDispatcher {
    private const val TAG = "ActionDispatcher"

    fun executeAction(context: Context, result: AssistantResult): Boolean {
        Log.d(TAG, "Executing Action: ${result.action}, Target: ${result.target}, Query: ${result.query}")

        val isFullAutomation = Storage.isFullAutomation(context)

        return when (result.action) {
            "OPEN_YOUTUBE_SEARCH" -> openYouTubeAndSearch(context, result.query)
            "OPEN_APP" -> openApp(context, result.target.ifBlank { result.query })
            "MAKE_CALL" -> makeCall(context, result.target)
            "SEND_SMS" -> sendSms(context, result.target, result.message)
            "SEND_WHATSAPP" -> sendWhatsApp(context, result.target, result.message, isFullAutomation)
            "SET_ALARM" -> setAlarm(context, result.message.ifBlank { "07:00" })
            "GET_TIME", "GET_DATE", "GENERAL_CHAT" -> true // Response spoken via TTS
            else -> false
        }
    }

    fun openYouTubeAndSearch(context: Context, query: String): Boolean {
        return try {
            val encoded = Uri.encode(query)
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=$encoded")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                setPackage("com.google.android.youtube") // Prefer native YouTube app if present
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            // Fallback to browser or generic intent
            try {
                val fallbackIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode(query)}")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(fallbackIntent)
                true
            } catch (ex: Exception) {
                Log.e(TAG, "Failed to open YouTube", ex)
                false
            }
        }
    }

    fun openApp(context: Context, appNameOrPackage: String): Boolean {
        if (appNameOrPackage.isBlank()) return false

        val pm = context.packageManager

        // First check if exact package name
        val directIntent = pm.getLaunchIntentForPackage(appNameOrPackage)
        if (directIntent != null) {
            directIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(directIntent)
            return true
        }

        // Search installed apps by label
        try {
            val packages = pm.getInstalledApplications(0)
            val lowerSearch = appNameOrPackage.lowercase()

            for (appInfo in packages) {
                val label = pm.getApplicationLabel(appInfo).toString().lowercase()
                if (label.contains(lowerSearch) || lowerSearch.contains(label)) {
                    val launchIntent = pm.getLaunchIntentForPackage(appInfo.packageName)
                    if (launchIntent != null) {
                        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(launchIntent)
                        return true
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error searching installed apps", e)
        }

        // Common known app fallback aliases
        val aliasPackageMap = mapOf(
            "youtube" to "com.google.android.youtube",
            "युट्युब" to "com.google.android.youtube",
            "whatsapp" to "com.whatsapp",
            "व्हाट्सएप" to "com.whatsapp",
            "facebook" to "com.facebook.katana",
            "फेसबुक" to "com.facebook.katana",
            "chrome" to "com.android.chrome",
            "क्रोम" to "com.android.chrome",
            "gallery" to "com.google.android.apps.photos",
            "ग्यालरी" to "com.google.android.apps.photos",
            "camera" to "android.media.action.IMAGE_CAPTURE",
            "क्यामेरा" to "android.media.action.IMAGE_CAPTURE"
        )

        for ((key, targetPkg) in aliasPackageMap) {
            if (appNameOrPackage.lowercase().contains(key)) {
                val launchIntent = pm.getLaunchIntentForPackage(targetPkg)
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(launchIntent)
                    return true
                }
            }
        }

        Toast.makeText(context, "'$appNameOrPackage' एप फेला परेन।", Toast.LENGTH_SHORT).show()
        return false
    }

    fun makeCall(context: Context, phoneOrName: String): Boolean {
        val cleanNumber = phoneOrName.replace(Regex("[^0-9+]"), "")
        return try {
            val uri = if (cleanNumber.isNotBlank()) Uri.parse("tel:$cleanNumber") else Uri.parse("tel:")
            val intent = Intent(Intent.ACTION_DIAL, uri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initiate call", e)
            false
        }
    }

    fun sendSms(context: Context, phone: String, message: String): Boolean {
        return try {
            val cleanPhone = phone.replace(Regex("[^0-9+]"), "")
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("smsto:${if (cleanPhone.isNotBlank()) cleanPhone else ""}")
                putExtra("sms_body", message)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to open SMS app", e)
            false
        }
    }

    fun sendWhatsApp(context: Context, phone: String, message: String, fullAutomation: Boolean): Boolean {
        return try {
            val cleanPhone = phone.replace(Regex("[^0-9]"), "")
            val formattedPhone = if (cleanPhone.startsWith("977")) cleanPhone else if (cleanPhone.length == 10) "977$cleanPhone" else cleanPhone
            val url = if (formattedPhone.isNotBlank()) {
                "https://api.whatsapp.com/send?phone=$formattedPhone&text=${Uri.encode(message)}"
            } else {
                "https://api.whatsapp.com/send?text=${Uri.encode(message)}"
            }

            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)

            if (fullAutomation) {
                // Schedule automated click via accessibility service after app launches
                android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                    clickSendViaAccessibility()
                }, 2000)
            }

            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to open WhatsApp", e)
            false
        }
    }

    fun setAlarm(context: Context, timeStr: String): Boolean {
        return try {
            val intent = Intent(android.provider.AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(android.provider.AlarmClock.EXTRA_MESSAGE, "Nepali Voice Assistant Alarm")
                putExtra(android.provider.AlarmClock.EXTRA_HOUR, 7)
                putExtra(android.provider.AlarmClock.EXTRA_MINUTES, 0)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to set alarm", e)
            false
        }
    }

    fun clickSendViaAccessibility(): Boolean {
        val service = MyAccessibilityService.getInstance() ?: return false
        val candidates = listOf("Send", "send", "पठाउनुहोस्", "पठाउनु", "पठाउने")
        for (candidate in candidates) {
            if (service.clickByText(candidate)) {
                return true
            }
        }
        return false
    }
}
