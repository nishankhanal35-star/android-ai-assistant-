package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "conversations")
data class ConversationEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val speaker: String, // "user" or "assistant"
    val messageText: String,
    val actionType: String = "NONE", // e.g., "OPEN_YOUTUBE", "MAKE_CALL", "SEND_SMS", "GENERAL_CHAT"
    val actionDetails: String = "",
    val isSuccess: Boolean = true
)
