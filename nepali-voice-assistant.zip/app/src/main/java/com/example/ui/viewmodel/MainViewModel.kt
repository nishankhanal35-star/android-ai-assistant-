package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.AssistantResult
import com.example.ai.GeminiService
import com.example.ai.VoiceManager
import com.example.ai.VoiceState
import com.example.actions.ActionDispatcher
import com.example.data.Storage
import com.example.data.db.AppDatabase
import com.example.data.db.ConversationEntity
import com.example.service.MyAccessibilityService
import com.example.service.VoiceForegroundService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val context: Context get() = getApplication<Application>().applicationContext
    private val db = AppDatabase.getInstance(context)
    private val dao = db.conversationDao()
    val voiceManager = VoiceManager.getInstance(context)

    val conversations = dao.getAllConversations()
    val voiceState = voiceManager.voiceState
    val rmsDb = voiceManager.rmsDb

    private val _apiKey = MutableStateFlow(Storage.getApiKey(context) ?: "")
    val apiKey: StateFlow<String> = _apiKey.asStateFlow()

    private val _elevenLabsApiKey = MutableStateFlow(Storage.getElevenLabsApiKey(context) ?: "")
    val elevenLabsApiKey: StateFlow<String> = _elevenLabsApiKey.asStateFlow()

    private val _elevenLabsVoiceId = MutableStateFlow(Storage.getElevenLabsVoiceId(context))
    val elevenLabsVoiceId: StateFlow<String> = _elevenLabsVoiceId.asStateFlow()

    private val _useElevenLabs = MutableStateFlow(Storage.isUseElevenLabs(context))
    val useElevenLabs: StateFlow<Boolean> = _useElevenLabs.asStateFlow()

    private val _isFullAutomation = MutableStateFlow(Storage.isFullAutomation(context))
    val isFullAutomation: StateFlow<Boolean> = _isFullAutomation.asStateFlow()

    private val _isWakeword = MutableStateFlow(Storage.isWakeword(context))
    val isWakeword: StateFlow<Boolean> = _isWakeword.asStateFlow()

    private val _speechPitch = MutableStateFlow(Storage.getSpeechPitch(context))
    val speechPitch: StateFlow<Float> = _speechPitch.asStateFlow()

    private val _speechRate = MutableStateFlow(Storage.getSpeechRate(context))
    val speechRate: StateFlow<Float> = _speechRate.asStateFlow()

    private val _isForegroundActive = MutableStateFlow(VoiceForegroundService.isRunning)
    val isForegroundActive: StateFlow<Boolean> = _isForegroundActive.asStateFlow()

    private val _isAccessibilityActive = MutableStateFlow(MyAccessibilityService.isServiceRunning())
    val isAccessibilityActive: StateFlow<Boolean> = _isAccessibilityActive.asStateFlow()

    fun refreshServiceStatuses() {
        _isForegroundActive.value = VoiceForegroundService.isRunning
        _isAccessibilityActive.value = MyAccessibilityService.isServiceRunning()
    }

    fun startListening() {
        voiceManager.startListening { text ->
            processCommandText(text)
        }
    }

    fun stopListening() {
        voiceManager.stopListening()
    }

    fun speak(text: String) {
        voiceManager.speak(text)
    }

    fun stopSpeaking() {
        voiceManager.stopSpeaking()
    }

    fun processCommandText(userText: String) {
        if (userText.isBlank()) return

        viewModelScope.launch {
            dao.insertConversation(
                ConversationEntity(
                    speaker = "user",
                    messageText = userText
                )
            )

            val result = GeminiService.processCommand(context, userText)
            val actionSuccess = ActionDispatcher.executeAction(context, result)

            dao.insertConversation(
                ConversationEntity(
                    speaker = "assistant",
                    messageText = result.reply,
                    actionType = result.action,
                    actionDetails = "Target: ${result.target}, Query: ${result.query}",
                    isSuccess = actionSuccess
                )
            )

            voiceManager.speak(result.reply)
        }
    }

    fun updateApiKey(newKey: String) {
        Storage.saveApiKey(context, newKey)
        _apiKey.value = newKey
    }

    fun updateElevenLabsSettings(key: String, voiceId: String, enabled: Boolean) {
        Storage.saveElevenLabsApiKey(context, key)
        Storage.saveElevenLabsVoiceId(context, voiceId)
        Storage.setUseElevenLabs(context, enabled)
        _elevenLabsApiKey.value = key
        _elevenLabsVoiceId.value = voiceId
        _useElevenLabs.value = enabled
    }

    fun setAutomationMode(isFull: Boolean) {
        Storage.setAutomationMode(context, isFull)
        _isFullAutomation.value = isFull
    }

    fun setListeningModeWakeword(isWakeword: Boolean) {
        Storage.setListeningModeWakeword(context, isWakeword)
        _isWakeword.value = isWakeword
    }

    fun setSpeechPitch(pitch: Float) {
        Storage.saveSpeechPitch(context, pitch)
        _speechPitch.value = pitch
        voiceManager.applyTtsSettings()
    }

    fun setSpeechRate(rate: Float) {
        Storage.saveSpeechRate(context, rate)
        _speechRate.value = rate
        voiceManager.applyTtsSettings()
    }

    fun toggleForegroundService(start: Boolean) {
        val intent = Intent(context, VoiceForegroundService::class.java)
        if (start) {
            intent.action = VoiceForegroundService.ACTION_START
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        } else {
            intent.action = VoiceForegroundService.ACTION_STOP
            context.stopService(intent)
        }
        _isForegroundActive.value = start
    }

    fun clearHistory() {
        viewModelScope.launch {
            dao.clearAll()
        }
    }
}
