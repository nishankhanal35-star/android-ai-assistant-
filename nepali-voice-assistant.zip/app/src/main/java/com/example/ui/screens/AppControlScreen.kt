package com.example.ui.screens

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SmartDisplay
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.actions.ActionDispatcher
import com.example.ui.viewmodel.MainViewModel

@Composable
fun AppControlScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isForegroundActive by viewModel.isForegroundActive.collectAsState()
    val isAccessibilityActive by viewModel.isAccessibilityActive.collectAsState()
    val isFullAutomation by viewModel.isFullAutomation.collectAsState()

    LaunchedEffect(Unit) {
        viewModel.refreshServiceStatuses()
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "नियन्त्रण र स्वचालित प्रणाली (App Control)",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )

        // System Services Status Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "सिस्टम सेवा स्थिति (Background Services)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Foreground Service Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "पृष्ठभूमि सेवा (Foreground Service)",
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = if (isForegroundActive) "सक्रिय (२४/७ बैकिङ कार्य सम्भव)" else "बन्द छ",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (isForegroundActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                        )
                    }
                    Switch(
                        checked = isForegroundActive,
                        onCheckedChange = { viewModel.toggleForegroundService(it) },
                        modifier = Modifier.testTag("foreground_service_switch")
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Accessibility Service Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "पहुँचयोग्यता सेवा (Accessibility Service)",
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = if (isAccessibilityActive) "सक्रिय (स्वचालित ट्याप र स्क्रिन नियन्त्रण)" else "बन्द छ (एप नियन्त्रणका लागि खोल्नुहोस्)",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (isAccessibilityActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                        )
                    }

                    OutlinedButton(
                        onClick = {
                            context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            })
                        },
                        modifier = Modifier.testTag("open_accessibility_settings")
                    ) {
                        Icon(
                            imageVector = Icons.Default.AccessibilityNew,
                            contentDescription = null,
                            modifier = Modifier.padding(end = 4.dp)
                        )
                        Text(if (isAccessibilityActive) "सेटिङ" else "खोल्नुहोस्")
                    }
                }
            }
        }

        // Automation Mode Mode Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "स्वचालन मोड (Automation Mode)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Conservative Option
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = !isFullAutomation,
                        onClick = { viewModel.setAutomationMode(false) },
                        modifier = Modifier.testTag("mode_conservative")
                    )
                    Column(modifier = Modifier.padding(start = 8.dp)) {
                        Text("सुरक्षित मोड (Conservative Mode)", fontWeight = FontWeight.Bold)
                        Text(
                            "एप खोलिदिन्छ र सन्देश तयार गर्छ, तर पठाउन तपाईंको सहमति माग्छ।",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Full Automation Option
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = isFullAutomation,
                        onClick = { viewModel.setAutomationMode(true) },
                        modifier = Modifier.testTag("mode_full")
                    )
                    Column(modifier = Modifier.padding(start = 8.dp)) {
                        Text("पूर्ण स्वचालित मोड (Full Automation Mode)", fontWeight = FontWeight.Bold)
                        Text(
                            "पहुँचयोग्यता सेवामार्फत आफैं क्लिक र सन्देश पठाउँछ।",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // Action Testing Playground Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "एप नियन्त्रण परीक्षण (Action Test Playground)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = { ActionDispatcher.openYouTubeAndSearch(context, "नेपाली लोक गीत") },
                    modifier = Modifier.fillMaxWidth().testTag("test_youtube_btn")
                ) {
                    Icon(imageVector = Icons.Default.SmartDisplay, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("युट्युबमा 'नेपाली लोक गीत' खोज्नुहोस्")
                }

                Spacer(modifier = Modifier.height(8.dp))

                Button(
                    onClick = { ActionDispatcher.makeCall(context, "9800000000") },
                    modifier = Modifier.fillMaxWidth().testTag("test_call_btn")
                ) {
                    Icon(imageVector = Icons.Default.Call, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("डायलरमा फोन कल परीक्षण गर्नुहोस्")
                }

                Spacer(modifier = Modifier.height(8.dp))

                Button(
                    onClick = { ActionDispatcher.sendWhatsApp(context, "", "नमस्ते, यो परीक्षण म्यासेज हो!", isFullAutomation) },
                    modifier = Modifier.fillMaxWidth().testTag("test_whatsapp_btn")
                ) {
                    Icon(imageVector = Icons.Default.Message, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("व्हाट्सएपमा म्यासेज तयार गर्नुहोस्")
                }
            }
        }
    }
}
